package com.sholeh.marketplacenj.adapter;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.sholeh.marketplacenj.R;
import com.sholeh.marketplacenj.model.province.Result;

import java.util.ArrayList;
import java.util.List;


public class ProvinsiAdapter extends BaseAdapter{

    private Activity activity;
    private LayoutInflater inflater;
    private List<Result> movieItems;
    private ArrayList<Result> listlokasiasli;


    public ProvinsiAdapter(Activity activity, List<Result> movieItems) {
        this.activity = activity;
        this.movieItems = movieItems;

        listlokasiasli = new ArrayList<Result>();
        listlokasiasli.addAll(movieItems);
    }

    @Override
    public int getCount() {
        return movieItems.size();
    }

    @Override
    public Object getItem(int location) {
        return movieItems.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.custom_item_alamat, null);

        TextView tv_category =  convertView.findViewById(R.id.tv_category);
//        TextView tv_detail =    convertView.findViewById(R.id.tv_detail);

        Result m = movieItems.get(position);

        tv_category.setText(m.getProvince());
//        tv_detail.setText(m.getProvinceId());

        return convertView;
    }

    @SuppressLint("DefaultLocale")
    public void filter(String charText)
    {
        charText = charText.toLowerCase();

        movieItems.clear();
        if (charText.length() == 0) {
            /* tampilkan seluruh data */
            movieItems.addAll(listlokasiasli);

        } else {
            for (Result lok : listlokasiasli) {
                if (lok.getProvince().toLowerCase().contains(charText)) {
                    movieItems.add(lok);
                } else {
                }

            }
        }

        notifyDataSetChanged();
    }

    public void setList(List<Result> movieItems){
        this.listlokasiasli.addAll(movieItems);
    }

}
