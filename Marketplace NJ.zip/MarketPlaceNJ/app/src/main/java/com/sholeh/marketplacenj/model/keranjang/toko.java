package com.sholeh.marketplacenj.model.keranjang;

public class toko {
    String nama_toko;

    public toko(String nama_toko){
        this.nama_toko = nama_toko;
    }

    public String getNama_toko() {
        return nama_toko;
    }

    public void setNama_toko(String nama_toko) {
        this.nama_toko = nama_toko;
    }
/*  public String getNama_toko() {
        return nama_toko;
    }

    public void setNama_toko(String nama_toko) {
        this.nama_toko = nama_toko;
    }*/
}
